from django.apps import AppConfig


class product_dbConfig(AppConfig):
    name = 'product_db'

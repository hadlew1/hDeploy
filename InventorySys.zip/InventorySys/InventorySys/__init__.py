"""
Package for InventorySys.
"""

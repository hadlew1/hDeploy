from django.apps import AppConfig


class frontendConfig(AppConfig):
    name = 'frontend'
